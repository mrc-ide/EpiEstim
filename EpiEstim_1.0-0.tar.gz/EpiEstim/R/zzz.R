.First.lib <- function (lib, pkg){
    packageStartupMessage("'My package is better than yours, fucker.' (Cori, pers. comm.).")
}
