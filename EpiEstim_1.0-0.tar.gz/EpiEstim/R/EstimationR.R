#############################################
#############################################
# Functions                                 #
#############################################
#############################################

#########################################################
# Cumulative density function of the gamma distribution # 
#########################################################

CDFGamma<-function(k,a,b)
{
	return(pgamma(k,shape=a,scale=b))
}

#########################################################
# Discretized shifted gamma distribution (with shift 1) #
#########################################################

DiscretizeShiftedGamma<-function(k,a,b)
{
	res<-k*CDFGamma(k,a,b)+(k-2)*CDFGamma(k-2,a,b)-2*(k-1)*CDFGamma(k-1,a,b)
	res<-res+a*b*(2*CDFGamma(k-1,a+1,b)-CDFGamma(k-2,a+1,b)-CDFGamma(k,a+1,b))
	res<-max(0,res)
	return(res)
}

#########################################################
# Calculates Lambda_t = Sum_1^t I_{t-s} * w_s           #
# with I incidence and w discrete SI distribution       #                          
#########################################################

CalculLambda <-function (I,SI.Distr)
{
	lambda <- vector()
	lambda[1]<-NA
	for (t in 2:length(I))
	{	
		lambda[t] <- sum(SI.Distr[1:t]*I[t:1])
	}
	return(lambda)
}

#########################################################
# Calculates the cumulative incidence over time steps   #
#########################################################

CalculIncidencePerTimeStep <-function (I,StartTimePeriods,EndTimePeriods)
{
	NbTimePeriods<-length(StartTimePeriods)
	IncidencePerTimeStep<-vector()
	for(i in 1:NbTimePeriods)
	{
		IncidencePerTimeStep[i]<-sum(I[StartTimePeriods[i]:EndTimePeriods[i]])
	}
	return(IncidencePerTimeStep)
}

#########################################################
# Calculates the parameters of the Gamma posterior      #
# distribution from the discrete SI distribution        #
#########################################################

PosteriorFromSIDistr <-function (I,SI.Distr,a.Prior,b.Prior,StartTimePeriods,EndTimePeriods)
{
	NbTimePeriods<-length(StartTimePeriods)
	lambda <- CalculLambda(I,SI.Distr)
	FinalMean.SI<-sum(SI.Distr*(0:(length(SI.Distr)-1)))

	a.Posterior<-vector()
	b.Posterior<-vector()

	for(t in 1:(NbTimePeriods))
	{	
		if(EndTimePeriods[t]>FinalMean.SI)
		{
			a.Posterior[EndTimePeriods[t]] <- a.Prior + sum(I[StartTimePeriods[t]:EndTimePeriods[t]])
			b.Posterior[EndTimePeriods[t]] <- 1 / ( 1/b.Prior + sum(lambda[StartTimePeriods[t]:EndTimePeriods[t]]) )
		}
	}
	return(list(a.Posterior,b.Posterior))
}

#########################################################
# Samples from the Gamma posterior distribution for a   #
# given mean SI and std SI                              #
#########################################################

SampleFromPosterior <-function (SampleSize,I,Mean.SI,Std.SI,a.Prior,b.Prior,StartTimePeriods,EndTimePeriods)
{
	NbTimePeriods<-length(StartTimePeriods)
	a.SI <- ((Mean.SI-1)/Std.SI)^2
	b.SI <- Std.SI^2/(Mean.SI-1)
	
	SI.Distr <- vector()
	for(t in 1:T)
	{
		SI.Distr[t] <- DiscretizeShiftedGamma(t-1,a.SI,b.SI)
	}
	FinalMean.SI<-sum(SI.Distr*(0:(length(SI.Distr)-1)))
	lambda <- CalculLambda(I,SI.Distr)

	SampleR.Posterior<-matrix(NA,SampleSize,T)

	a.Posterior<-vector()
	b.Posterior<-vector()

	for(t in 1:NbTimePeriods)
	{
		if(EndTimePeriods[t]>FinalMean.SI)
		{
			a.Posterior[EndTimePeriods[t]] <- a.Prior + sum(I[StartTimePeriods[t]:EndTimePeriods[t]])
			b.Posterior[EndTimePeriods[t]] <- 1 / ( 1/b.Prior + sum(lambda[StartTimePeriods[t]:EndTimePeriods[t]]) )
			SampleR.Posterior[,EndTimePeriods[t]]<-rgamma(SampleSize,shape=a.Posterior[EndTimePeriods[t]], scale = b.Posterior[EndTimePeriods[t]])
		}
	}
	return(list(SampleR.Posterior,SI.Distr))
}

#########################################################
# Main function                                         #
#########################################################

EstimateR<-function(I,Mean.Prior=5,Std.Prior=5,StartTimePeriods,EndTimePeriods,method,SampleSizeforR,SampleSizeforSI,Mean.SI,Std.SI,Std.Mean.SI,Min.Mean.SI,Max.Mean.SI,Std.Std.SI,Min.Std.SI,Max.Std.SI,SI.Distr,CV.Posterior=0.3,plot=FALSE)
{
	
	### Error messages ###

	if(is.vector(I)==FALSE)
	{
		stop("Incidence must be a vector.")
	}
	T<-length(I)
	for(i in 1:T)
	{
		if(I[i]<0)
		{
			stop("Incidence must be a positive vector.")
		}
	}

	if(Mean.Prior<=0)
	{
		stop("Mean.Prior must be >0.")
	}
	if(Std.Prior<=0)
	{
		stop("Std.Prior must be >0.")
	}
	a.Prior <- (Mean.Prior/Std.Prior)^2
	b.Prior <- Std.Prior^2/Mean.Prior	

	if(is.vector(StartTimePeriods)==FALSE)
	{
		stop("StartTimePeriods must be a vector.")
	}
	if(is.vector(EndTimePeriods)==FALSE)
	{
		stop("EndTimePeriods must be a vector.")
	}
	if(length(StartTimePeriods)!=length(EndTimePeriods))
	{
		stop("StartTimePeriods and EndTimePeriods must have the same length.")
	}
	NbTimePeriods<-length(StartTimePeriods)
	for(i in 1:NbTimePeriods)
	{
		if(StartTimePeriods[i]>EndTimePeriods[i])
		{
			stop("StartTimePeriods[i] must be <= EndTimePeriods[i] for all i.")
		}
		if(StartTimePeriods[i]<1 || StartTimePeriods[i]%%1!=0)
		{
			stop("StartTimePeriods must be a vector of >0 integers.")
		}
		if(EndTimePeriods[i]<1 || EndTimePeriods[i]%%1!=0)
		{
			stop("EndTimePeriods must be a vector of >0 integers.")
		}
	}
	if(method!=1 && method !=2 && method!=3)
	{
		stop("The method argument must be one of 1, 2 or 3.")
	}

	if(method==1)
	{
		if(is.vector(SI.Distr)==FALSE)
		{
			stop("method 1 requires that SI.Distr must be a vector.")
		}
		if(SI.Distr[1]!=0)
		{
			stop("method 1 requires that SI.Distr[1] = 0.")
		}
		if(length(SI.Distr)>1)
		{
			for(i in 2:length(SI.Distr))
			{
				if(SI.Distr[i]<0)
				{
					stop("method 1 requires that SI.Distr must be a positive vector.")
				}
			}
		}
		if(abs(sum(SI.Distr)-1)>0.01)
		{
			stop("method 1 requires that SI.Distr must sum to 1.")
		}
	}

	if(method==2)
	{
		if(Mean.SI<1)
		{
			stop("method 2 requires a value >1 for Mean.SI.")
		}
		if(Std.SI<0)
		{
			stop("method 2 requires a >0 value for Std.SI.")
		}
	}

	if(method==3)
	{
		if(Mean.SI<0)
		{
			stop("method 3 requires a >0 value for Mean.SI.")
		}
		if(Std.SI<0)
		{
			stop("method 3 requires a >0 value for Std.SI.")
		}
		if(SampleSizeforR<=0 || SampleSizeforR%%1!=0)
		{
			stop("method 3 requires a >0 integer value for SampleSizeforR.")
		}
		if(SampleSizeforSI<=0 || SampleSizeforSI%%1!=0)
		{
			stop("method 3 requires a >0 integer value for SampleSizeforSI.")
		}
		if(Std.Mean.SI<0)
		{
			stop("method 3 requires a >0 value for Std.Mean.SI.")
		}
		if(Min.Mean.SI<1)
		{
			stop("method 3 requires a value >=1 for Min.Mean.SI.")
		}
		if(Max.Mean.SI<Mean.SI)
		{
			stop("method 3 requires that Max.Mean.SI >= Mean.SI.")
		}
		if(Mean.SI<Min.Mean.SI)
		{
			stop("method 3 requires that Mean.SI >= Min.Mean.SI.")
		}
		if(Max.Mean.SI-Mean.SI!=Mean.SI-Min.Mean.SI)
		{
			warning("The distribution you chose for the mean SI is not centered around the mean.")
		}
		if(Std.Std.SI<0)
		{
			stop("method 3 requires a >0 value for Std.Std.SI.")
		}
		if(Min.Std.SI<0)
		{
			stop("method 3 requires a >0 value for Min.Std.SI.")
		}
		if(Max.Std.SI<Std.SI)
		{
			stop("method 3 requires that Max.Std.SI >= Std.SI.")
		}
		if(Std.SI<=Min.Std.SI)
		{
			stop("method 3 requires that Std.SI >= Min.Std.SI.")
		}
		if(Max.Std.SI-Std.SI!=Std.SI-Min.Std.SI)
		{
			warning("The distribution you chose for the std of the SI is not centered around the mean.")
		}
	}

	if(CV.Posterior<0)
	{
		stop("CV.Posterior must be >0.")
	}
	MinNbCasesPerTimePeriod<-ceiling(1/CV.Posterior^2-a.Prior)
	IncidencePerTimeStep<-CalculIncidencePerTimeStep(I,StartTimePeriods,EndTimePeriods)

	if(IncidencePerTimeStep[1]<MinNbCasesPerTimePeriod)
	{
		warning("You're estimating R too early in the epidemic to get the desired posterior CV.")
	}

	if(plot!=TRUE && plot!=FALSE)
	{
		stop("plot must be TRUE or FALSE.")
	}


	### What does each method do ###

	if(method==1)
	{
		SIUncertainty<-"N"
		ParametricSI<-"N"
	}
	if(method==2)
	{
		SIUncertainty<-"N"
		ParametricSI<-"Y"
	}
	if(method==3)
	{
		SIUncertainty<-"Y"
	}
	
	if(SIUncertainty=="Y")
	{
		Mean.SI.sample<-rep(-1,SampleSizeforSI)
		Std.SI.sample<-rep(-1,SampleSizeforSI)
		for (k in 1:SampleSizeforSI)
		{
			while(Mean.SI.sample[k]<Min.Mean.SI || Mean.SI.sample[k] >Max.Mean.SI)
		   	{
		   		Mean.SI.sample[k] <- rnorm(1, mean=Mean.SI, sd=Std.Mean.SI)
		   	}
		   	while(Std.SI.sample[k]<Min.Std.SI || Std.SI.sample[k] >Max.Std.SI || Std.SI.sample[k]>Mean.SI.sample[k])		
		   	{
				# the last condition ensures that the pdf of the SI is 0 at time 0
		     		Std.SI.sample[k] <- rnorm(1, mean=Std.SI, sd=Std.Std.SI)
		   	}
		}

		Rsample<-matrix(NA,SampleSizeforR*SampleSizeforSI,T)
		SI.Distr<-matrix(NA,SampleSizeforSI,T+1)
	
		for (k in 1:SampleSizeforSI)
		{
			#print(k)
			prov<-SampleFromPosterior(SampleSizeforR,I,Mean.SI.sample[k],Std.SI.sample[k],a.Prior,b.Prior,StartTimePeriods,EndTimePeriods)
			Rsample[((k-1)*SampleSizeforR+1):(k*SampleSizeforR),ceiling(Mean.SI.sample[k]):T]<-prov[[1]][,ceiling(Mean.SI.sample[k]):T]
			SI.Distr[k,1:T]<-prov[[2]]
		}
	
		Mean.Posterior <- apply(Rsample,2,mean,na.rm=TRUE)
		Std.Posterior <- apply(Rsample,2,sd,na.rm=TRUE)
		
		Quantile.0.025.Posterior <- apply(Rsample,2,quantile,0.025,na.rm=TRUE)
		Quantile.0.05.Posterior <- apply(Rsample,2,quantile,0.05,na.rm=TRUE)
		Quantile.0.25.Posterior <- apply(Rsample,2,quantile,0.25,na.rm=TRUE)
		Median.Posterior <- apply(Rsample,2,median,na.rm=TRUE)
		Quantile.0.75.Posterior <- apply(Rsample,2,quantile,0.75,na.rm=TRUE)
		Quantile.0.95.Posterior <- apply(Rsample,2,quantile,0.95,na.rm=TRUE)
		Quantile.0.975.Posterior <- apply(Rsample,2,quantile,0.975,na.rm=TRUE)
		
	}else
	{
		if(ParametricSI=="Y")
		{
			a.SI <- ((Mean.SI-1)/Std.SI)^2
			b.SI <- Std.SI^2/(Mean.SI-1)
			SI.Distr <- vector()
			for(t in 1:T)
			{
				SI.Distr[t] <- DiscretizeShiftedGamma(t-1,a.SI,b.SI)
			}
		}
		if(length(SI.Distr)<T+1){SI.Distr[(length(SI.Distr)+1):(T+1)]<-0}
		FinalMean.SI<-sum(SI.Distr*(0:(length(SI.Distr)-1)))
		FinalStd.SI<-sqrt(sum(SI.Distr*(0:(length(SI.Distr)-1))^2)-FinalMean.SI^2)
		
		post<-PosteriorFromSIDistr(I,SI.Distr,a.Prior,b.Prior,StartTimePeriods,EndTimePeriods)	
		a.Posterior<-post[[1]]
		b.Posterior<-post[[2]]

		Mean.Posterior <- a.Posterior*b.Posterior
		Std.Posterior <- sqrt(a.Posterior)*b.Posterior
	
		Quantile.0.025.Posterior <- qgamma(0.025, shape=a.Posterior, scale = b.Posterior, lower.tail = TRUE, log.p = FALSE)
		Quantile.0.05.Posterior <- qgamma(0.05, shape=a.Posterior, scale = b.Posterior, lower.tail = TRUE, log.p = FALSE)
		Quantile.0.25.Posterior <- qgamma(0.25, shape=a.Posterior, scale = b.Posterior, lower.tail = TRUE, log.p = FALSE)
		Median.Posterior <- qgamma(0.5, shape=a.Posterior, scale = b.Posterior, lower.tail = TRUE, log.p = FALSE)
		Quantile.0.75.Posterior <- qgamma(0.75, shape=a.Posterior, scale = b.Posterior, lower.tail = TRUE, log.p = FALSE)
		Quantile.0.95.Posterior <- qgamma(0.95, shape=a.Posterior, scale = b.Posterior, lower.tail = TRUE, log.p = FALSE)
		Quantile.0.975.Posterior <- qgamma(0.975, shape=a.Posterior, scale = b.Posterior, lower.tail = TRUE, log.p = FALSE)
	}
	
	### results
	
	results<-list()

	results$R<-as.data.frame(cbind(StartTimePeriods,EndTimePeriods,Mean.Posterior[EndTimePeriods],Std.Posterior[EndTimePeriods],Quantile.0.025.Posterior[EndTimePeriods],Quantile.0.05.Posterior[EndTimePeriods],Quantile.0.25.Posterior[EndTimePeriods],Median.Posterior[EndTimePeriods],Quantile.0.75.Posterior[EndTimePeriods],Quantile.0.95.Posterior[EndTimePeriods],Quantile.0.975.Posterior[EndTimePeriods]))
	names(results$R)<-c("StartTimePeriods","EndTimePeriods","Mean(R)","Std(R)","Quantile.0.025(R)","Quantile.0.05(R)","Quantile.0.25(R)","Median(R)","Quantile.0.75(R)","Quantile.0.95(R)","Quantile.0.975(R)")
	

	if(SIUncertainty=="Y")
	{
		results$SIDistr<-as.data.frame(cbind(Mean.SI.sample,Std.SI.sample))
	}else
	{
		if(ParametricSI=="Y")
		{
			MaxT<-min(which(abs(cumsum(SI.Distr)-1)<0.000001))
			results$SIDistr<-as.data.frame(cbind(0:(MaxT-1),SI.Distr[1:MaxT]))
			names(results$SIDistr)<-c("k","w[k]")
		}else
		{
			results$SIDistr<-as.data.frame(cbind(FinalMean.SI,FinalStd.SI))
			names(results$SIDistr)<-c("Mean Discrete SI","Std Discrete SI")
		}
	}

	if(plot==TRUE)
	{
		grey <- "#999999"
		if(SIUncertainty=="Y")
		{
			par(mfcol=c(2,2),las=1,cex.main=1.5,cex.lab=1.2,cex.axis=1,mar=c(4.8,4.8,2.4,0.8),mgp=c(4,1,0))
			plot(I,type="s",bty="n",xlab="",ylab="",main="Epidemic curve")
			title(xlab="Time",ylab="Incidence",line = 3)
	
			plot(Median.Posterior,type="l",bty="n",xlab="",ylab="",main="Estimated R",ylim=c(0,max(Quantile.0.975.Posterior,na.rm=TRUE)),xlim=c(1,T))
			title(xlab="Time",ylab="R",line = 3)

			polygon(c(EndTimePeriods,rev(EndTimePeriods)),c(Quantile.0.025.Posterior[EndTimePeriods],rev(Quantile.0.975.Posterior[EndTimePeriods])),col=grey,border=FALSE)
			lines(Median.Posterior)
			lines(0:T,rep(1,T+1),lty=2)
			legend("topright",c("Median","95%CrI"),col=c("Black",grey),lwd=c(1,10),bty="n",cex=1.2)

			hist(Mean.SI.sample,xlab="",ylab="",main="Explored \n mean serial intervals",freq=FALSE)
			title(xlab="Mean serial interval",ylab="Density",line = 3)

			hist(Std.SI.sample,xlab="",ylab="",main="Explored \n std serial intervals",freq=FALSE)
			title(xlab="Std serial interval",ylab="Density",line = 3)
		}else
		{
			par(mfrow=c(3,1),las=1,cex.main=1.8,cex.lab=1.5,cex.axis=1.2,mar=c(6,6,3,1),mgp=c(4,1,0))
			plot(I,type="s",bty="n",xlab="Time",ylab="Incidence",main="Epidemic curve")
	
			plot(1:max(EndTimePeriods),Median.Posterior,type="l",bty="n",xlab="Time",ylab="R",main="Estimated R",ylim=c(0,max(Quantile.0.975.Posterior,na.rm=TRUE)),xlim=c(1,T))
	
			polygon(c(1:max(EndTimePeriods),rev(1:max(EndTimePeriods))),c(Quantile.0.025.Posterior,rev(Quantile.0.975.Posterior)),col=grey,border=FALSE)
			lines(1:max(EndTimePeriods),Median.Posterior)
			lines(0:T,rep(1,T+1),lty=2)
			legend("topright",c("Median","95%CrI"),col=c("Black",grey),lwd=c(1,10),bty="n",cex=1.2)
			if(method==1)
			{
				FinalMean.SI<-results$SIDistr[1,1]
				FinalStd.SI<-results$SIDistr[1,2]
			}
			if(method==2)
			{
				FinalMean.SI<-sum(results$SIDistr[,1]*results$SIDistr[,2])
				FinalStd.SI<-sqrt(sum(results$SIDistr[,1]^2*results$SIDistr[,2])-FinalMean.SI^2)
			}
			plot(0:(length(SI.Distr)-1),SI.Distr,type="s",bty="n",xlab="Time",ylab="Frequency",main="Serial interval distribution",xlim=c(0,FinalMean.SI+6*FinalStd.SI))
		}

	}

	return(results)

}
	
	









