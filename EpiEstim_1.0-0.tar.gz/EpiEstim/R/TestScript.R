
# method 1

load("C:\\Documents\\IC\\My project\\EpiEstim\\data\\2009PandemicFluSchoolPennsylvania.RData")
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=1,SI.Distr=SI.Distr,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(c(-1,Incidence),Mean.Prior=5,Std.Prior=5,method=1,SI.Distr=SI.Distr,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=-1,Std.Prior=5,method=1,SI.Distr=SI.Distr,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=-1,method=1,SI.Distr=SI.Distr,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=1,SI.Distr=SI.Distr[-1],StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=1,SI.Distr=c(SI.Distr,0.5),StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=1,SI.Distr=c(SI.Distr,-0.000001),StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=1,SI.Distr=SI.Distr,StartTimePeriods=8:(30-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=1,SI.Distr=SI.Distr,StartTimePeriods=0:(31-7),EndTimePeriods=0:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=1,SI.Distr=SI.Distr,StartTimePeriods=1:(31-7),EndTimePeriods=1:(31-7)+6,plot=33)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=1,SI.Distr=SI.Distr,StartTimePeriods=1:(31-7),EndTimePeriods=1:(31-7)+6,plot=TRUE)

# method 2

toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=2,Mean.SI=2.6,Std.SI=1.5,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(c(-1,Incidence),Mean.Prior=5,Std.Prior=5,method=2,Mean.SI=2.6,Std.SI=1.5,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=-1,Std.Prior=5,method=2,Mean.SI=2.6,Std.SI=1.5,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=-1,method=2,Mean.SI=2.6,Std.SI=1.5,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=2,Mean.SI=0.9,Std.SI=1.5,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=2,Mean.SI=2.6,Std.SI=-0.1,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=2,Mean.SI=2.6,Std.SI=1.5,StartTimePeriods=8:(30-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=2,Mean.SI=2.6,Std.SI=1.5,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=2)

# method 3

toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(c(-1,Incidence),Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=-1,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=-1,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100.5,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=-100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=0.9,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=0.9,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=1.5,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=-0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=-0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=-0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=0.9,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(30-7),EndTimePeriods=8:(31-7)+6,plot=TRUE)
toto=EstimateR(Incidence,Mean.Prior=5,Std.Prior=5,method=3,SampleSizeforR=100,SampleSizeforSI=100,Mean.SI=2.6,Std.Mean.SI=0.5,Min.Mean.SI=1,Max.Mean.SI=8,Std.SI=1.5,Std.Std.SI=0.5,Min.Std.SI=0.2,Max.Std.SI=1.7,StartTimePeriods=8:(31-7),EndTimePeriods=8:(31-7)+6,plot=22)




Mean.Prior=5
Std.Prior=5
method=3
SampleSizeforR=100
SampleSizeforSI=100
Mean.SI=2.6
Std.Mean.SI=0.5
Min.Mean.SI=0
Max.Mean.SI=8
Std.SI=1.5
Std.Std.SI=0.5
Min.Std.SI=0.2
Max.Std.SI=0.7
StartTimePeriods=8:(31-7)
EndTimePeriods=8:(31-7)+6
plot=TRUE




Quantile.0.025.Posterior=(toto$R)$"Quantile.0.025(R)"
Quantile.0.975.Posterior=(toto$R)$"Quantile.0.975(R)"
Median.Posterior=(toto$R)$"Median(R)"
SI.Distr=toto$SIDistr[,2]

Mean.Prior=5
Std.Prior=5
I=Incidence
StartTimePeriods=8:(31-7)
EndTimePeriods=8:(31-7)+6
plot=TRUE
method=2
Mean.SI=2.6
Std.SI=1.5
CV.Posterior=0.3
